/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package coffee.pos_take5;

/**
 *
 * @author jhonb
 */
public class Pos_take5 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
