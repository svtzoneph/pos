/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
class slide {

    static void init(Login_2 login, Register register) {
        
    }

    static void setAnimate(int i) {
        
    }

    static void show(int i) {
        
    }
    
}
